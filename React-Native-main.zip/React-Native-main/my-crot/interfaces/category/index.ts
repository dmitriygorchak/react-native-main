export interface ICategoryItem {
    "id": number,
    "name": string,
    "image": string,
    "description": string,
    "userId": number
}