// @ts-ignore

import {BASE_URL} from "@/constants/Urls";

const APP_ENV = {
    API_URL: BASE_URL,
}

export { APP_ENV };